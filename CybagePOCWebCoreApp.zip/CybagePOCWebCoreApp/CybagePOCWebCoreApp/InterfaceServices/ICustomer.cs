﻿using CybagePOCWebCoreApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CybagePOCWebCoreApp.InterfaceServices
{
    public interface ICustomer
    {
        Task<List<CustomerModel>> GetCustomers();
        Task<CustomerModel> GetCustomerById(string id);
        Task<CustomerModel> CreateCustomer(CustomerModel customer);
        Task<CustomerModel> UpdateCustomer(string id, CustomerModel customer);
        Task<bool> DeleteCustomer(string id);
    }
}
